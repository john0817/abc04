--复合类型：枚举类型、集合类型
--1. 枚举类型
-- 表现出来是字符串，但是内部运算和存储时使用数字，所以速度非常快。
-- 用于实现有限个【单选类】的状态
-- enum('男','女','保密');
create table member(
	id int primary key auto_increment,
	name varchar(10),
	gender enum('男','女','保密')
);

insert into member values(null,'张三',1);
insert into member values(null,'李四','女');
insert into member values(null,'王五',3);

--2. 集合类型
-- 表现出来也是字符串，但是内部在运算时使用的是二进制位，存储时使用数字，所有速度非常快。
-- 用于实现有限个【复选类】的状态
-- set('新品','精品','热销','售罄');
create table goods(
	id int primary key auto_increment,
	name varchar(10),
	status set('新品','精品','热销','售罄') comment '商品状态'
);
insert into goods values(null,'小米手机',1);
insert into goods values(null,'华为P20',3);
insert into goods values(null,'罗技鼠标','精品,热销,售罄');