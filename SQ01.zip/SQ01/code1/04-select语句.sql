--1. select语句概述
--select 用于实现数据查询，一共由七大部分组成，各个部分都可以省略，要么不出现，出现就必须按固定的位置。
-- select [字段列表] [from子句] [where子句] [group by子句] [having子句] [order by子句] [limit子句]

--1.1 字段列表
--1.1.1 字段表达式
select 1+1;
select now();

--1.1.2 字段列表
select name,age from student;

--1.1.3 * 通配符，代表所有字段
select * from student;

--1.1.4 表名.字段名
select student.name,student.age from student;

--1.1.5 字段别名 as
select student.name,student.age,classes.classname from student left join classes on student.class_id=classes.id;
select student.name as 姓名,student.age as 年龄,classes.classname as 班级 from student left join classes on student.class_id=classes.id;

--1.1.5 聚合函数
--注意：一般配合分组进行分组统计
count() --统计总数量
sum()	--求和
avg()	--求平均
max()	--求最大值
min()	--求最小值
group_concat()	--分组拼接

select min(age) from student;
select avg(age) from student;
select count(*) from student;


--1.2 from子句 => 数据源子句
--1.2.1 1个表名
select * from 表名;
select * from student;

--1.2.2 多个表名，用英文逗号隔开
select * from student,classes; --将两个数据表进行拼接，产生一个迪卡尔积

--1.2.3 表别名
select * from student,classes where student.class_id=classes.id and student.age<30;
select * from student s,classes c where s.class_id=c.id and s.age<30; --取别名后更加精简


--1.3 where子句 => 条件子句，位于from子句的后边，用于对数据源进行过滤提取出符合条件的数据
select * from student where age>30;

--1.3.1 关系运算符  > < = >= <= != <>
select * from student where age<30;
select * from student where age=23;
select * from student where age<>23;

--1.3.2 like模糊查询
-- % 匹配0个或多个字符， _匹配1个字符
select * from student where name like '%诸葛%'; --找出姓诸葛的同学

--1.3.3 in 或 not in => 在集合中或没在集合中
--找出ID是1 2 3 的数据
select * from student where id=1 or id=2 or id=3;
--标准写法
select * from student where id in (1,2,3);
select * from student where id not in (1,2,3);

--1.3.4 between and 或 not between and => 找到两者之间的数据， 或没在两者之间的数据
--找出年龄位于 24 到30之间的数据
select * from student where age >=24 and age<=30;
--标准写法
select * from student where age between 24 and 30;

--1.3.5 is null 或 is not null
--找出没有班级的同学名单
select * from student where class_id is null;
select * from student where class_id is not null;

--1.3.6 逻辑运算符 and与  or或  not非
--找出5班年龄小于30岁的同学
select * from student where class_id=5 and age<30;

--找出年龄小于20或年龄大于50
select * from student where age<20 or age>50;

--1.3.7 where的原理：从数据源中提取出每一条数据，逐条与条件进行对比，满足就查询出来，不满足就剔除
select * from student where 1; --找出所有数据


--1.4 group by子句 => 分组统计
--统计每个班的人数
--1) 按班级进行分组
select * from student group by class_id;
--2) 根据分组进行统计
select count(*),class_id from student group by class_id;

--统计每个班的平均年龄
select class_id,avg(age) as 平均年龄 from student group by class_id desc;


--1.5 having子句 => 根据分组进行条件判断
--查询出平均年龄大于30岁的班级
--1) 查询出每个班级的平均年龄
select class_id,avg(age) from student group by class_id;

--2) 过滤平均年龄只要大于30的
select class_id,avg(age) as aveAge from student group by class_id having aveAge>30;

--3) 获取年龄大于30的班级的名单（了解）
select class_id,avg(age),group_concat(name) as 名单 from student group by class_id having avg(age)>30;


--1.6 order by子句 => 排序
-- order by 字段名 asc, 字段名2 desc
-- 根据年龄进行从小到大排序
select * from student order by age asc;
select * from student order by age desc;

--1.7 limit 子句 => 限定输出
-- limit 10; 查询出前10条
-- limit 5,10; 查询从第5开始的10条数据
-- 查询出年龄最大的三个同学
select * from student order by age desc limit 3;

-- 查询出ID=5开始的三条数据
select * from student where id>=5 order by id asc limit 0,3;

--注意：limit通常用于实现分页，还可以用于排行榜 Top10

--小结，select的完整格式：
-- select [选项] 字段1,字段2,字段n from 数据表名 别名,数据表名2 别名2 where 条件 group by 字段名 desc|asc having 条件 order by
--  字段名1 asc,字段名2 desc limit 起始位置,数量;

--2. select的选项
--2.1 默认是 all
select all class_id from student;

--2.2 去除重复 distinct
select distinct class_id from student;
