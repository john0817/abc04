--SQL = DDL + DML

--DDL 数据定义语言
--1. 数据库操作
--1.1 创建数据库
create database `数据库名`;

--1.2 查看数据库
show databases; --查看当前服务器中的所有数据库
show create database 数据库名; --查看数据库的建立语句

--1.3 修改数据库
alter database 数据库名 charset=utf8;

--1.4 删除数据库
drop database 数据库名;

--1.5 切换/使用数据库
use 数据库名;

--2. 数据表操作
--2.1 创建数据表
create table `数据表名`(
	字段名 字段类型 其它属性,
	字段名2 字段类型2 其它属性2
)engine=innodb default charset=utf8;

--2.2 查看数据表
show tables; --查看当前数据库中的 所有数据表
desc 数据表名; --查看数据表的结构
show create table 数据表名; --查看建表语句

--2.3 修改数据表
alter table 表名 engine=存储引擎 charset=字符集; --修改表选项
rename table 表名 to 新表名; --修改表名、移动表到新的数据库

--2.4 删除数据表
drop table 数据表名;

--3. 字段操作
--3.1 新增字段
alter table 表名 add column 字段名 字段定义 before 字段名;

--3.2 查看字段
desc 表名;

--3.3 修改字段
alter table 表名 modify column 字段名 新的字段定义; --修改字段定义
alter table 表名 change column 旧字段名 新字段名 新的字段定义; --修改字段名和定义

--3.4 删除字段
alter table 表名 drop column 字段名;


--DML 数据管理语言
--4. 数据行操作
--4.1 新增数据
insert into 表名(字段列表) values(值列表);

--4.2 查看数据
select 字段名列表 from 表名 where 条件 order by 字段名 desc limit 0,10;
--完整的select语句包含七大子句
select 字段名子句 from子句 where条件子句 group by子句 having子句 order by子句 limit子句;

--4.3 修改数据
update 表名 set 字段名=新的值,字段名2=新的值2 where 条件;

--4.4 删除数据
delete from 表名 where 条件; --注意：一般工作中不需要该语句，数据都是不删除的


--5. 数据类型
--整数类型
int
tinyint unsigned
bigint

--小数类型
float
double
decimal

--字符串类型
char
varchar
text
longtext

--日期时间类型
datetime
date
time
year
month
timestamp default current_timestamp

--复合类型
enum
set

--6. 字段属性
not null  |  null --能不能为空
default --默认值
primary key --主键/主索引
auto_increment --自增
unique --唯一键/唯一索引
index --普通索引
comment --备注

--7. 其它
set names gbk; --设置交互字符集

