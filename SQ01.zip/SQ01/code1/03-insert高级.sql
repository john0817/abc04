--1. 一次插入多条数据【重点】
insert into 表名(字段列表) values
(值的列表),
(值的列表),
(值的列表),
(值的列表),
(值的列表),
(值的列表),
(值的列表),
(值的列表); --注意： () 称为行构造符，一对()就是一行
insert into student(name,age,class_id) values('诸葛亮',88,5),('赵云',24,5);

--2. 插入或更新数据（不常用）
--注意：如果没有数据则插入数据，如果有数据则修改，必须要有一个评估是否重复的字段作为依据
insert into 表名 (字段1, 字段2, 字段3, ...) values (值1, 值2, 值3, ...)
on duplicate key update 字段2=值2, 字段3=值3;

insert into student values(null,'诸葛亮',88,5) on duplicate key update name='诸葛孔明'; --插入一条新数据
insert into student values(13,'诸葛亮',88,5) on duplicate key update name='诸葛孔明'; --如果13存在则修改，不存在就新增

--3. 插入数据来源于数据表【重点】
insert into student2 select id,name from student where id <=3; --数据类型与字段数量必须与表格结构一致

--3.1 补充：将查询到的结果存储为新的数据表【重点】
create table student3 select * from student where id<=3;

--4. 使用set插入数据（不常用）
insert into student set name='司马义',age=87;
insert into classes set classname='H50710',room='A04';