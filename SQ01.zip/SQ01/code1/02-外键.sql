--1. 外键
--外键也称为外键约束，用别人表（父表）的数据来约束当前表（子表）的字段

--关系型数据主要存储两个方面：
--1) 数据自身的属性（内在特征）
--2) 数据与数据之间的关系 【重点】
--	1:n		一对多	=> 【在多端（学生）创建一个字段，保存一端（班级）的标识(ID)】
--	1:1		一对一	=> 在任意端创建字段保存另一端的标识
--	n:m		多对多	=> 创建一个单独的关系表，将多对多化解成一对多进行存储

--创建学生表
create table student(
	id int primary key auto_increment,
	name varchar(10),
	age tinyint unsigned default 0,
	class_id int default 0
) engine=innodb default charset=utf8;

insert into student values(null,'张飞',23,1),(null,'关羽',23,1),(null,'刘备',23,1);

--创建班级表
create table classes(
	id int primary key auto_increment,
	classname varchar(10),
	room char(3)
) engine=innodb default charset=utf8;

insert into classes values(null,'PHP0613','A07'),(null,'UI0620','A01');

--1.1 创建外键【重点】
alter table student add foreign key (class_id) references classes(id); --注意：如何创建外键约束时数据不合理，则不能创建成功

--体验外键约束
insert into student values(null,'曹操',25,5); --不能添加一个父表中不存在的数据
delete from classes where id=2; --不能删除子表中已存在的数据

--1.2 查看外键名
show create table student; --外键名：student_ibfk_1

--1.3 删除外键【重点】
alter table student drop foreign key student_ibfk_1; --注意：创建外键时自动创建了普通索引，在删除时不会自动删除
alter table student drop key class_id;

--1.4 外键级联操作
--cascade 级联操作
--set null 置null
alter table student add foreign key (class_id) references classes(id) on update cascade on delete set null;

