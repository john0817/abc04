1.公务人员基本信息表
users
id，姓名，年龄，手机号，工号
1 	张三	18
2	李四	19
3	王五	20

create table users(
id int primary key auto_increment,
name varchar(10),
age tinyint unsigned,
tel char(11)
)default charset=utf8;

insert into users(id,name,age) values(null,'张三',18),(null,'李四',19),(null,'王五',22);


2.公务人员详细联系方式表
users_more
user_id，性别，身份证，邮箱，家庭住址，简介

create table users_more(
user_id int,
gender enum('男','女','未知'),
cid char(18),
email varchar(50),
address varchar(100),
intro text
)default charset=utf8;

insert into users_more(user_id,gender,cid) values(1,1,'0000000000000'),(2,2,'0000000000000'),(3,3,'0000000000000');


3.岗位表
post
id，岗位名称，岗位介绍			x公务员ID
1	会计	专用于作帐			1,2????
2	出纳	专用于收钱			1
3	保安	专用于看门			2,3????
4	科长	专用于管办公室		3

create table post(
id int primary key auto_increment,
name varchar(10),
intro text
)default charset=utf8;

insert into post(name) values('会计'),('出纳'),('保安'),('科长');

3.1 公务员岗位分配表
users_post
id，公务员ID，岗位ID，从事时间，结束时间
1	1			1		2018-08-30	2018-09-01
2	1			2		2018-08-30	2018-09-01
3	2			1		2018-08-30	2018-09-01
4	3			3		...
5	3			4		...

create table users_post(
id int primary key auto_increment,
userid int,
postid int
)default charset=utf8;

insert into users_post(userid,postid) values(1,1),(1,2),(2,1),(3,3),(3,4);

4.职能表
func
id，职能名称，职能介绍						属于哪个岗位
1	做帐		应该适当的做漂亮			1
2	查帐		审核帐目					1
3	看大门		在大门看有没有人放炸弹		3
4	泊车		帮助领导停车				3,4 ???
5	看报纸		没事干就看报				4,3,2,1 ????
6	安排工作	科长特长					4
7	收钱		数钱数到手抽筋				2
8	报销		给钱给别人					2

create table func(
id int primary key auto_increment,
name varchar(10),
intro text
)default charset=utf8;

insert into func(name) values('做帐'),('查帐'),('看大门'),('泊车'),('看报纸'),('安排工作'),('收钱'),('报销');

4.1 岗位职能表
post_func
id，岗位ID，职能ID
1	1		1
2	1		2
3	3		3
4	3		4
5	4		4
6	4		5
7	3		5
8	2		5

create table post_func(
id int primary key auto_increment,
postid int,
funcid int
)default charset=utf8;

insert into post_func(postid,funcid) values(1,1),(1,2),(3,3),(3,4),(4,4),(4,5),(3,5),(2,5);


--1. 一个公务人员的完整信息
select * from users left join users_more on users.id=users_more.user_id;

--2. 查出一个公务人员及其岗位信息
select * from users_post up left join users u on up.userid=u.id;
select up.id,u.name,up.postid from users_post up left join users u on up.userid=u.id;
select up.id,u.name,p.name from users_post up left join users u on up.userid=u.id left join post p on up.postid=p.id;
select up.id,u.name,group_concat(p.name) from users_post up left join users u on up.userid=u.id left join post p on up.postid=p.id group by u.name;

--3. 查出一个公务人员及其职能信息
-- 公务员表 => 岗位表 => 职能表
select * from post_func pf left join users_post up on pf.postid=up.postid;
select up.userid,pf.funcid from post_func pf left join users_post up on pf.postid=up.postid;
select u.name,group_concat(f.name) from post_func pf left join users_post up on pf.postid=up.postid left join users u on up.userid=u.id left join func f on pf.funcid=f.id group by u.name;

