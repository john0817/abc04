1. 视图 view
	1) 什么是视图？
		视图是由SELECT语句组成的虚拟表
		
	2) 为什么要用视图
		a. 简化复杂的查询操作
		b. 隐藏真实表结构和其它数据，便数据更加安全
		
	3) 使用视图
		a. 创建视图
			create view 视图名 as select语句
			示例：
			create view student_top3 as select * from student order by height desc limit 3;
			
		b. 使用视图
			select * from 视图名; --将视图当成数据表进行查询
			
		c. 查看建立视图语句
			show create view 视图名;
			
		d. 修改视图
			alter view 视图名 as 新的select语句;
			示例：
			alter view student_top3 as select * from student order by age desc limit 3;
			
		e. 删除视图
			drop view 视图名;
			示例：
			drop view student_top3;
			
	4) 视图的注意点
		a. 由于视图只是一个虚拟表，只存储了一个select语句，所以不能insert插入数据、update修改数据、delete删除数据
		b. 视图中只保存了select语句，每次执行都会重新查询，可以得到最新的数据（自动更新）
		c. 可以让select语句对字段取别名，隐藏真实表结构
			create view student_top10 as select name as 姓名,age as 年龄,height as 身高 from student order by age desc limit 10;
			
2. 索引
	1) 什么是索引
		用于帮助快速的确定记录位置的功能，相当于目录
		
	2) 索引分类
		a. 主索引 => 主键 => primary key 不能为空，不能重复，一个表只能有一个
		b. 唯一索引 => 唯一键 => unique  不能重复，可以为空，一个表可以有多个
			alter table goods modify name varchar(10) unique;
			insert into goods(name,status) values('华为P20',1);
			
		c. 普通索引 => 普通键 => key
		d. 全文索引	=> 为指定的关键词建立索引，提高查询效率
		
	3) 查看查询状态
		explain select查询语句 \G;
		
	
3. 事务
	1) 什么是事务？
		事务就是一种数据库机制，将一组SQL语句看成一个整体，要么一起成功，要么一起失败。
		保证数据完整性和安全性。
		
	2) 事务的使用
		a. 开启事务机制
			start transaction; ===	begin;
			
		b. 提交事务
			commit;
			
		c. 事务回滚
			rollback;
			
		注意： 如果执行了 rollback或commit 事务就结束，再次使用还得再开启。
		
	3) 事务的细节
		a. 事务开启以后，所有的操作都是临时操作，可以选择回滚或永久提交到数据库中。
		
		
需求：张飞找刘备借50块买酒
	1) 在刘备的帐号上减去50
		update student set money=money-50 where name='刘备';
		
	2) 在张飞的帐号上加50
		update student set money=money+50 where name='张飞';
	
		