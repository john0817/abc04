1. 什么是联合查询
	将多条语句的查询结果拼接在一起，就是联合查询
	
2. 实现联合查询
	select语句1 union select语句2
	示例：
		select id,name,age from student where age>30
		union
		select * from classes;
	
3. 联合查询的细节
	1) UNION ALL	在联合时，将数据全部显示出来
		select * from student where id<=3
		union all
		select * from student where class_id=5;
		
	2) UNION DISTINCT （默认的）在联合时，自动去除重复数据
		select * from student where id<=3
		union DISTINCT
		select * from student where class_id=5;
		
	3) UNION排序
		select * from student where age>=25 order by age desc
		union all
		select * from student where class_id=3 order by age asc;
		--上边语句会报错
		--解决办法：使用小括号进行构造行
		(select * from student where age>=25 order by age desc)
		union all
		(select * from student where class_id=3 order by age asc);
		--上边语句能实现查询，但是顺序不对
		--解决办法：加 limit子句
		(select * from student where age>=25 order by age desc limit 1000)
		union all
		(select * from student where class_id=3 order by age asc limit 1000);
		
		--注意：要实现联合查询各自排序必须加 () 和 limit子句
		