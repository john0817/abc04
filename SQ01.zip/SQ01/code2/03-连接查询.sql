1. 什么是连接查询？
	连接查询是指将多个数据表根据字段关联，构造成一个新的数据源，进行的查询
	
2. 为什么必须用连接查询？
	1) 让数据保存在各自表中，减少冗余，节省硬盘空间
	2) 在显示时必须使用连接查询将数据拼接以后再显示
	3) 速度快（与跨表查询相比）
	
3. 使用连接查询
	1) 内连接
		inner join => join
		两边表在连接时，必须同时成功才能查询出
		select * from student join classes on student.class_id=classes.id;
	
	2) 外连接
		a. 左外连接 left join
			根据左表（左边的表）显示数据，即使没匹配成功也能显示左边表的数据
			select * from student left join classes on student.class_id=classes.id;
		
		b. 右外连接 right join
			根据右表（右边的表）显示数据，即使没匹配成功也能显示右边表的数据
			select * from student right join classes on student.class_id=classes.id;
			

	3) 交叉连接
		cross join 同内连接 join
		
	4) 自然连接
		natural join 自动判断两张表中的关联字段，要求关联字段必须同名，省略on
		select * from `order` natural join customer;
		
	5) on 和 using
		a. on 用于实现两个表的连接条件
			select * from `order` o join customer c on c.cust_id=o.cust_id;
			
		b. using 用于实现自动连接，使用两张表中都有的字段（自己写）实现连接
			select * from `order` o join customer c using(cust_id);
		
--综合示例： 学生之间的乒乓球比赛
--比赛结果表：
create table result(
id int primary key auto_increment,
player1 int,
score tinyint,
player2 int,
matchtime timestamp default current_timestamp
);

insert into result(player1,score,player2) values(1,'10:10',2);
insert into result(player1,score,player2) values(3,'20:22',5);
insert into result(player1,score,player2) values(2,'1:2',17);

+----+---------+-------+---------+---------------------+
| id | player1 | score | player2 | matchtime           |
+----+---------+-------+---------+---------------------+
|  1 |   张飞  | 10:10 |    关羽 | 2018-08-29 15:55:44 |
|  2 |    刘备 | 20:22 |    曹操 | 2018-08-29 15:55:44 |
|  3 |    关羽 | 1:2   |    马超 | 2018-08-29 15:55:45 |
+----+---------+-------+---------+---------------------+
如何实现？
select r.id,s1.name as player1,r.score,s2.name as player2,r.matchtime from result r join student s1 on r.player1=s1.id join student s2 on r.player2=s2.id;




