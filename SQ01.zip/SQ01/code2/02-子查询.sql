--找出所有身高最高的同学的信息
--传统实现：只能找出身高最高的1个，如果有多个身高相同，都是最高，就无法实现
select * from student order by height desc limit 1;

--子查询
--1) 找出身高最高的 身高值
--select height from student order by height desc limit 1;
select max(height) from student; --通过聚合函数实现查找最高值

--2) 再根据身高值查询所有符合条件的数据
select * from student where height=(select max(height) from student);

--1. 什么是子查询
--在查询语句中出现另外一个查询语句，称为子查询，为父查询提供帮助

--2. 子查询的分类
--	根据子查询所在位置划分为：
	from子查询： 子查询的结果作为父查询的数据源
	where子查询： 子查询的结果作为父查询的条件
	
-- 根据子查询的返回结果划分为：
	标量子查询（一行一列），一个字段
	列子查询（多行一列），一列
	行子查询（一行多列），一行
	表子查询（多行多列），一个表格

	
	
	
--2.1 where子查询： 子查询为父查询提供条件
--需求：找出年龄最小的同学的信息
--1) 找出年龄最小的年龄值
	select min(age) from student;
	
--2) 根据最小的年龄值查询出数据
	select * from student where age=(select min(age) from student);


--2.2 from子查询：子查询的结果作为父查询的数据源
--需求：找到每个班级内身高最高的学生？
--  利用分组的特性（第一个出来的数据作为代表），让最高的人排前面作为代表，再分组

--1) 让最高的人排前面，根据身高进行倒序排列
select * from student order by height desc;

--2) 根据结果进行分组，身高最高的人成为代表
select * from (select * from student order by height desc) temp group by class_id;
--注意：from子查询作为一个数据源进行使用，【必须加别名】
--缺点：如果一个班有多个身高都一样高，而且都是最高，只能找出其中一个


--2.3 标量子查询
select * from student where age=(select min(age) from student);


--2.4 列子查询  => 返回结果是一列
--需求：找到没有学生的班级
--1) 找出有学生的班级
select distinct class_id from student where class_id is not null;

--2) 没有在该班级列表中的班级就是没学生的
select * from classes where id not in (select distinct class_id from student where class_id is not null);
select * from classes where id =some(select distinct class_id from student where class_id is not null);
--注意：子查询中如果出现null在对比时会出问题
--注意：还有几个特殊函数 =some() 相当于 in ， !=all() 相当于 not in


--2.5 行子查询 => 返回结果是一行
--需求：找到每个班级内身高最高的学生？
--1) 先找到每个班级最高的身高值： 身高值，班级ID
select max(height),class_id from student group by class_id;

--2) 根据身高值和班级ID查找学生信息
select * from student where (height,class_id) in (select max(height),class_id from student group by class_id);
--注意： 可以将字段拼接成一行进行比对，使用行构造符 ()



--2.6 表子查询
select * from (select * from student order by height desc) temp group by class_id;





--3. exists 或 not exists
--exists是一个函数，如果有值则返回1，没有值则返回0
--需求：找到没有学生的班级！
select * from classes where not exists(select * from student where student.class_id=classes.id);





--中午作业：删除重复的数据，保留ID最小的那一个
insert into student3 values(null,'张飞',18,6),(null,'马超',18,6);

--1) 根据重复字段进行分组，将第一条作为代表，找出出现第一次的数据
select * from student3 group by name;

--2) 将查到的不重复的数据进行另存为表格【推荐使用】
--create table newstudent select * from student3 group by name;

--2) 删除没在ID集合中的数据
delete from student3 where id not in (select * from (select id from student3 group by name) tmp);
--注意：因为父查询与子查询不能同表操作（删改），所以必须让子查询变成孙子查询




